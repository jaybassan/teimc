# teimc

This is a package containing functions useful for analyzing imaging mass cytometry data with tellurium isotopes. 

Some of the functions in this package are discussed in our preprint article on bioRxiv:
doi: 10.1101/567685
link: https://www.biorxiv.org/content/10.1101/567685v1