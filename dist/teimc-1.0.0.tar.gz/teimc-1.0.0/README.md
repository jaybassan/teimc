# teimc

This is a package containing functions useful for analyzing imaging mass cytometry data with tellurium isotopes. 

Some of the functions in this package are discussed in our preprint article (citation to follow).